﻿
var world;
var beginContactFunctions = new Array();
var endContactFunctions = new Array();
inspectFunctions.push(function (component, cname) {
    if ("beginContact" in component) {
        beginContactFunctions.push({
            name: component.gameObject.name.value,
            component: component,
            gameObject: component.gameObject,
            fn: component.beginContact
        });
    }
    if ("endContact" in component) {
        endContactFunctions.push({
            name: component.gameObject.name.value,
            component: component,
            gameObject: component.gameObject,
            fn: component.endContact
        });
    }
    if ("impact" in component) {
        impactFunctions.push({
            name: component.gameObject.name.value,
            component: component,
            gameObject: component.gameObject,
            fn: component.impact
        });
    }
});
gm.p2World = function () {
    initiatePhysicsEngine();    
}
gm.p2World.prototype.create = function () {
}
gm.p2World.prototype.update = function (d) {
    world.step(1/60);    
}
if (!objects.P2World)
    addGameObjectBase({
        name: {
            value: 'P2World'
        },
        position: {
        },
        p2World: {
        }
    });
constantGameObjects.push(JSON.stringify({
    name: {
        value: 'P2World'
    },
    position: {
    },
    p2World: {
    }
}));
function newPhysicMaterial(mat) {
    if (!("mats" in window))
        window.mats = {};

    var newMat = new p2.Material();
    if (mat.properties.stiffness == -1)
        mat.properties.stiffness = Number.MAX_VALUE;
    window.mats[mat.name] = ({
        name: mat.name,
        mat: newMat,
        properties: mat.properties
    }); //collision itself
    for (var i in window.mats) {
        var oldMaterial = window.mats[i];
        world.addContactMaterial(new p2.ContactMaterial(oldMaterial.mat, newMat, {
            friction: mat.properties.friction + oldMaterial.properties.friction,
            restitution: Math.min(1, mat.properties.restitution + oldMaterial.properties.restitution),
            stiffness: Math.min(mat.properties.stiffness, oldMaterial.properties.stiffness),
            surfaceVelocity: mat.properties.surfaceVelocity + oldMaterial.properties.surfaceVelocity
        }));
    }
}
function initializeMaterials() {
    window.groundBody = new p2.Body();
    world.addBody(groundBody);
    newPhysicMaterial({
        name: 'default',
        properties: { friction: 0.3, restitution: 0, stiffness: -1, surfaceVelocity: 0 }
    });
    if ("resources" in window)
        for (var i in resources) {
            if (i.endsWith(".physics")) {
                var prop = JSON.parse(resources[i].data);
                newPhysicMaterial({
                    name: i, properties: prop
                });
            }
        }

}

function initiatePhysicsEngine() {
    window.world = new p2.World({
        gravity: [0, 982]
    });
    world.solver.iterations = 8;
    world.solver.tolerance = 0.01;
    initializeMaterials();
    world.on("impact", function (evt) {
        var bodyA = evt.bodyA,
            bodyB = evt.bodyB;
        for (var i = 0; i < impactFunctions.length; i++) {
            if (impactFunctions[i].gameObject && impactFunctions[i].gameObject && impactFunctions[i].gameObject.Physics
                && impactFunctions[i].gameObject.Physics.body) {
                if (impactFunctions[i].gameObject.Physics.body == bodyA)
                    impactFunctions[i].fn.apply(impactFunctions[i].component, [getGameObject(bodyB), bodyB, evt]);
                else if (impactFunctions[i].gameObject.Physics.body == bodyB)
                    impactFunctions[i].fn.apply(impactFunctions[i].component, [getGameObject(bodyA), bodyA, evt]);
            }
        }
    });
    world.on("beginContact", function (evt) {
        var bodyA = evt.bodyA,
            bodyB = evt.bodyB;
        for (var i = 0; i < beginContactFunctions.length; i++) {
            if (beginContactFunctions[i].gameObject && beginContactFunctions[i].gameObject && beginContactFunctions[i].gameObject.Physics
                && beginContactFunctions[i].gameObject.Physics.body) {
                if (beginContactFunctions[i].gameObject.Physics.body == bodyA)
                    beginContactFunctions[i].fn.apply(beginContactFunctions[i].component, [getGameObject(bodyB), bodyB, evt]);
                else if (beginContactFunctions[i].gameObject.Physics.body == bodyB)
                    beginContactFunctions[i].fn.apply(beginContactFunctions[i].component, [getGameObject(bodyA), bodyA, evt]);
            }
        }
    });
    world.on("endContact", function (evt) {
        var bodyA = evt.bodyA,
            bodyB = evt.bodyB;
        for (var i = 0; i < endContactFunctions.length; i++) {
            if (endContactFunctions[i].gameObject && endContactFunctions[i].gameObject && endContactFunctions[i].gameObject.Physics
                && endContactFunctions[i].gameObject.Physics.body) {
                if (endContactFunctions[i].gameObject.Physics.body == bodyA)
                    endContactFunctions[i].fn.apply(endContactFunctions[i].component, [getGameObject(bodyB), bodyB, evt]);
                else if (endContactFunctions[i].gameObject.Physics.body == bodyB)
                    endContactFunctions[i].fn.apply(endContactFunctions[i].component, [getGameObject(bodyA), bodyA, evt]);
            }
        }
    });
}
