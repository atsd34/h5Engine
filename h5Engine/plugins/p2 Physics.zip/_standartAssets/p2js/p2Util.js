window.PhysicsInitialized = false;
console.log("using p2");
gm.Physics = function () {
    this.debugDraw = false;
    this.fillColor = "FFFFFF";
    this.lineColor = "000000";
    this.reloadInEditor = { reloadME: true }
    this.reloadME = 0;
    this.previousType = undefined;
    this.worksInEditor = true;
    this.dontSerialize = { Editing: true, reloadME: true, selectedVerticesIndex: true }
    this.serializeObject = { vertices: true }
    this.comboBoxes = { colliderType: ["box", "circle", "polygon"] };
    if ("assetList" in window) {
        this.comboBoxes.physicsMaterial = ["default"];
        for (var i = 0; i < assetList.length; i++) {
            if (assetList[i].name.endsWith(".physics"))
                this.comboBoxes.physicsMaterial.push({
                    text: assetList[i].name, value: assetList[i].name
                })
        }
    }
    this.colliderType = "box";
    this.private = { preX: true, preY: true, preRot: true, angle: true, Editing: true, reloadME: true };
    this.radius = 1;
    this.width = 0;
    this.height = 0;
    this.damping = 0.1;
    this.physicsMaterial = "default";
    this.mass = 5;
    this.preX = 0;
    this.preY = 0;
    this.preRot = 0;
    this.static = false;
    this.isSensor = false;
    this.fixedRotation = false;
    this.fixedX = false;
    this.fixedY = false;
    this.angle = 0;
    this.Editing = false;
    this.velocityX = 0;
    this.velocityY = 0;
    this.bodyDifference = { x: 0, y: 0 }
    this.vertices = [{ x: -50, y: -50 },
    { x: 50, y: -50, c: 0x00ff00 },
    { x: 50, y: 50 },
    { x: -50, y: 50 }]
    this.resetBox = function () {
        this.width = this.gameObject.position.width;
        this.height = this.gameObject.position.height;
        this.colliderType = "box";
        this.vertices = [{ x: -50, y: -50 },
        { x: 50, y: -50, c: 0x00ff00 },
        { x: 0, y: 50 }];
        var go = goBack(this.gameObject);
        socketemit("gameobject", { action: "change", name: this.gameObject.name.value, plugin: "Physics", newval: go.Physics });
    }
    this.customDiv = {
        centerMe: function (container) {
            var $this = this;
            addMenu("Reset BOX", function () {
                $this.resetBox();
            }, "", container, "");
            addMenu("Edit", function () {
                $(".btnPhysicsEdit").removeClass("btn-danger");
                if ($this.Editing != true) {
                    $this.Editing = true;
                    lockedSelection = true;
                    $(".btnPhysicsEdit").html('Stop');
                    $(".btnPhysicsEdit").addClass("btn-danger");
                }
                else {
                    lockedSelection = false;
                    $this.Editing = false;
                    $(".btnPhysicsEdit").html('Edit');
                    var go = goBack($this.gameObject);
                    socketemit("gameobject", { action: "change", name: $this.gameObject.name.value, plugin: "Physics", newval: go.Physics });
                }
            }, "", container, "btnPhysicsEdit");
            if (this.Editing == true) {
                $(".btnPhysicsEdit").html('Stop');
                $(".btnPhysicsEdit").addClass("btn-danger");
            }
        }
    }
}
gm.Physics.prototype.editorPrivates = function () {
    if (this.colliderType == "box") {
        this.private.radius = true;
        this.private.width = false;
        this.private.height = false;
        if (selectedSprite == this.gameObject) {
            var JSONReadyGO = goBack(selectedSprite);
            socketemit("selectgameobject", JSONReadyGO);
        }
    }
    else if (this.colliderType == "circle") {
        this.private.width = true;
        this.private.height = true;
        this.private.radius = false;
        if (selectedSprite == this.gameObject) {
            var JSONReadyGO = goBack(selectedSprite);
            socketemit("selectgameobject", JSONReadyGO);
        }
    }
    else if (this.colliderType == "polygon") {
        this.private.width = true;
        this.private.height = true;
        this.private.radius = true;
        if (selectedSprite == this.gameObject) {
            var JSONReadyGO = goBack(selectedSprite);
            socketemit("selectgameobject", JSONReadyGO);
        }
    }

}
gm.Physics.prototype.createBody = function () {
    var shape;
    switch (this.colliderType) {
        case "box":
            ;

            shape = new p2.Box({ width: this.width * Math.abs(this.gameObject.position.scaleX), height: this.height * Math.abs(this.gameObject.position.scaleY) });
            this.body.addShape(shape);
            break;
        case "circle":

            shape = new p2.Circle({ radius: Math.abs(this.radius * this.gameObject.position.scaleX) });
            this.body.addShape(shape);
            break;
        case "polygon":
            var bodypos = {
                x: this.body.position[0], y: this.body.position[1]
            };
            var vertices = [];
            for (var i = 0; i < this.vertices.length; i++) {
                vertices.push([this.vertices[i].x * this.gameObject.position.scaleX, this.vertices[i].y * this.gameObject.position.scaleY]);
            }

            this.body.fromPolygon(vertices);
            this.bodyDifference = {
                x: this.body.position[0] - bodypos.x,
                y: this.body.position[1] - bodypos.y
            }
            for (var i = 0; i < this.body.shapes.length; i++) {
                this.body.shapes[i].position[0] = this.body.shapes[i].position[0] + this.bodyDifference.x;
                this.body.shapes[i].position[1] = this.body.shapes[i].position[1] + this.bodyDifference.y;
            }
            break;
        default:
    }

    this.body.gameObjectName = this.gameObject.name.value;
}
gm.Physics.prototype.changeAttributes = function () {
    var $this = this;
    newObservable(this, "colliderType", undefined, function () {
        $this.reloadME++;
    });
    newObservable(this, "mass", undefined, function () {
        $this.reloadME++;
    });
    newObservable(this, "static", undefined, function () {

        $this.reloadME++;
    });
    newObservable(this, "fixedRotation", undefined, function () {
        $this.reloadME++;
    });
    newObservable(this, "fixedX", undefined, function () {
        $this.reloadME++;
    });
    newObservable(this, "fixedY", undefined, function () {
        $this.reloadME++;
    });
    newObservable(this, "debugDraw", undefined, function () {
        $this.reloadME++;
    });



    newObservable(this, "physicsMaterial", undefined, function () {
        for (var i = 0; i < $this.body.shapes.length; i++) {
            $this.body.shapes[i].material = window.mats[$this.physicsMaterial].mat;
        }
    })();
    newObservable(this, "damping", undefined, function () {
        $this.body.damping = parseFloat($this.damping);
    })();
    newObservable(this, "velocityY", undefined, function () {
        $this.body.velocity[1] = parseFloat($this.velocityY);
    })();
    newObservable(this, "velocityX", undefined, function () {
        $this.body.velocity[0] = parseFloat($this.velocityX);
    })();
    newObservable(this, "isSensor", undefined, function () {
        if ($this.isSensor)
            for (var i = 0; i < $this.body.shapes.length; i++) {
                $this.body.shapes[i].sensor = true;
            }
        else
            for (var i = 0; i < $this.body.shapes.length; i++) {
                $this.body.shapes[i].sensor = false;
            }

    })();
}
gm.Physics.prototype.create = function () {
    if (!INEDITOR) {
        var $this = this;
        this.gameObject.position.scaleXFunctions.Physics = function () {
            $this.reloadME++;
        }
        this.gameObject.position.scaleYFunctions.Physics = function () {
            $this.reloadME++;
        }
        this.body = new p2.Body({
            mass: this.static ? 0 : this.mass,
            position: [this.gameObject.position.x, this.gameObject.position.y],
            angle: this.gameObject.position.rotation * Math.PI / 180,
            fixedRotation: this.fixedRotation,
            fixedX: this.fixedX,
            fixedY: this.fixedY
        });
        this.createBody();

        this.changeAttributes();

        world.addBody(this.body);

        this.graphics = new PIXI.Graphics();
        if (this.debugDraw) {
            var fc = parseInt("0x" + this.fillColor);
            var lc = parseInt("0x" + this.lineColor);
            this.graphics.beginFill(fc, 1);

            if (this.colliderType == "box") {
                DrawBox(0, 0,
                    this.width, this.height,
                    0, this.graphics
                    , 0.5
                    , 0.5
                    , lc, 1, true, this.gameObject.position.container, true);
                this.gameObject.position.container.addChild(this.graphics);
            }
            if (this.colliderType == "circle") {
                DrawCircle(0, 0,
                    this.radius,
                    0, this.graphics
                    , 0.5
                    , 0.5
                    , lc, 1, this.gameObject.position.container, true);
            }
            if (this.colliderType == "polygon") {

                DrawPolygon(0, 0,
                    this.vertices,
                    0, this.graphics, lc, 1, false, this.gameObject.position.container);
            }

            this.graphics.endFill();
        }
    }
    else {
        if (this.width == 0 && this.height == 0 && this.colliderType == "box") {
            this.resetBox();
        }
        var $this = this;
        newObservable(this, "colliderType", undefined, function () {

            $this.editorPrivates();
        })();

        newObservable(this, "debugDraw", undefined, function () {

            if ($this.debugDraw) {
                $this.private.fillColor = false;
                $this.private.lineColor = false;
            } else {

                $this.private.fillColor = true;
                $this.private.lineColor = true;
            }
            if (selectedSprite == $this.gameObject) {
                var JSONReadyGO = goBack(selectedSprite);
                socketemit("selectgameobject", JSONReadyGO);
            }
        })();
        this.selectedVerticesIndex = -1;
        this.mouseDown = function (m, e) {
            this.selectedVerticesIndex = -1;
            if (selectedSprite == this.gameObject && this.Editing) {
                for (var i = 0; i < this.vertices.length; i++) {
                    delete this.vertices[i].c;
                }
                for (var i = 0; i < this.vertices.length; i++) {
                    var v = this.vertices[i];
                    var dx = m.x - v.x - this.gameObject.position.x;
                    var dy = m.y - v.y - this.gameObject.position.y;
                    if (Math.sqrt(dx * dx + dy * dy) < 16) {
                        v.c = 0x00ff00;
                        this.selectedVerticesIndex = i;

                    }
                }
                if (this.selectedVerticesIndex == -1) {
                    for (var i = 0; i < this.vertices.length; i++) {
                        var v1 = this.vertices[i];
                        var v2;
                        if (i == this.vertices.length - 1)
                            v2 = this.vertices[0];
                        else
                            v2 = this.vertices[i + 1];
                        var dx1 = m.x - v1.x - this.gameObject.position.x;
                        var dy1 = m.y - v1.y - this.gameObject.position.y;
                        var dx2 = m.x - v2.x - this.gameObject.position.x;
                        var dy2 = m.y - v2.y - this.gameObject.position.y;
                        var dx = v1.x - v2.x;
                        var dy = v1.y - v2.y;
                        var len = Math.sqrt(dx * dx + dy * dy);
                        var len1 = Math.sqrt(dx1 * dx1 + dy1 * dy1);
                        var len2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);
                        if (Math.abs(len1 + len2 - len) < 16) {
                            ;
                            var vnew = {
                                x: parseInt(m.x - this.gameObject.position.x),
                                y: parseInt(m.y - this.gameObject.position.y),
                                c: 0x00ff00
                            }
                            this.vertices.splice(i + 1, 0, vnew);
                            this.selectedVerticesIndex = i + 1;
                            return;
                        }
                    }
                }

            }
        }
        this.mouseMove = function (m, e) {
            if (selectedSprite == this.gameObject && this.Editing && this.selectedVerticesIndex > -1) {
                this.vertices[this.selectedVerticesIndex].x = parseInt(m.x - this.gameObject.position.x);
                this.vertices[this.selectedVerticesIndex].y = parseInt(m.y - this.gameObject.position.y);
            }
        }
        this.mouseUp = function (m, e) {
            this.selectedVerticesIndex = -1;
        }

        this.graphics = new PIXI.Graphics();
    }

}
gm.Physics.prototype.update = function (dt) {
    if (!INEDITOR) {
        if (this.gameObject.position.x == this.preX)
            this.gameObject.position.x = this.body.position[0];
        else
            this.body.position[0] = this.gameObject.position.x;
        if (this.gameObject.position.y == this.preY)
            this.gameObject.position.y = this.body.position[1];
        else
            this.body.position[1] = this.gameObject.position.y;

        if (this.gameObject.position.rotation == this.preRot) {
            this.gameObject.position.rotation = this.body.angle * 180 / Math.PI;
        }
        else {
            this.body.angle = this.gameObject.position.rotation * Math.PI / 180;
        }
        this.preX = this.gameObject.position.x;
        this.preY = this.gameObject.position.y;
        this.preRot = this.gameObject.position.rotation;
    }
    if (INEDITOR) {

        this.gameObject.position.container.removeChild(this.graphics);
        delete this.graphics;
        this.graphics = new PIXI.Graphics();

        this.graphics.beginFill(0xFF3300, 0.01);
        if (this.colliderType == "box") {
            DrawBox(0, 0,
                this.width, this.height,
                0, this.graphics
                , 0.5
                , 0.5
                , 0xff0000, 0.6, false, this.gameObject.position.container);
        }
        if (this.colliderType == "circle") {
            DrawCircle(0, 0,
                this.radius,
                0, this.graphics
                , 0.5
                , 0.5
                , 0xff0000, 0.6, this.gameObject.position.container);
        }
        if (this.colliderType == "polygon") {

            DrawPolygon(0, 0,
                this.vertices,
                0, this.graphics, 0xff0000, 0.6, true, this.gameObject.position.container);
            if (this.Editing && lastKey != undefined && lastKey.keyCode == 46) {
                lastKey = undefined;
                var newVertices = new Array();
                for (var i = 0; i < this.vertices.length; i++) {
                    if (this.vertices[i].c == undefined)
                        newVertices.push(this.vertices[i]);
                }
                this.vertices = newVertices;
            }
        }
        this.graphics.endFill();
    }
}
gm.Physics.prototype.dispose = function () {
    if (this.body)
        world.removeBody(this.body)
    if (this.graphics) {
        this.gameObject.position.container.removeChild(this.graphics);
        delete this.graphics;
    }

}
var mousedown;
gm.revoluteConstraint = function () {
    this.requires = "Physics";
    this.reloadInEditor = {
        otherGameObjectName: true,
        AnchorX: true,
        AnchorY: true,
        OtherAnchorX: true,
        OtherAnchorY: true
    }
    this.otherGameObjectName = "";
    this.AnchorX = 0;
    this.AnchorY = 0;
    this.OtherAnchorX = 0;
    this.OtherAnchorY = 0;
    this.motorSpeed = 0;
}
gm.revoluteConstraint.prototype.afterCreate = function () {

    var $this = this;
    if (!this.otherGameObjectName) {
        var other;
        other = window.groundBody;
        this.revolute = new p2.RevoluteConstraint(this.gameObject.Physics.body, other, {
            worldPivot: [this.AnchorX + this.gameObject.position.x, this.AnchorY + this.gameObject.position.y],
            collideConnected: false
        });
        world.addConstraint(this.revolute);
        newObservable(this, "motorSpeed", undefined, function () {
            if ($this.motorSpeed == 0)
                $this.revolute.disableMotor();
            else {
                $this.revolute.enableMotor();
                $this.revolute.setMotorSpeed($this.motorSpeed);
            }
        })();
    } else {


        other = objects[$this.otherGameObjectName].Physics.body;
        $this.revolute = new p2.RevoluteConstraint($this.gameObject.Physics.body, other, {
            localPivotA: [$this.AnchorX, $this.AnchorY],
            localPivotB: [$this.OtherAnchorX, $this.OtherAnchorY],
            collideConnected: false
        });
        world.addConstraint($this.revolute);
        newObservable($this, "motorSpeed", undefined, function () {
            if ($this.motorSpeed == 0)
                $this.revolute.disableMotor();
            else {
                $this.revolute.enableMotor();
                $this.revolute.setMotorSpeed($this.motorSpeed);
            }
        })();

    }

}
gm.revoluteConstraint.prototype.dispose = function () {
    world.removeConstraint(this.revolute);
}

gm.distanceConstraint = function () {
    this.requires = "Physics";
    this.reloadInEditor = {
        otherGameObjectName: true,
        AnchorX: true,
        AnchorY: true,
        OtherAnchorX: true,
        OtherAnchorY: true
    }
    this.otherGameObjectName = "";
    this.AnchorX = 0;
    this.AnchorY = 0;
    this.OtherAnchorX = 0;
    this.OtherAnchorY = 0;
    this.minDistance = -1;
    this.maxDistance = 200;
}
gm.distanceConstraint.prototype.afterCreate = function () {


    var $this = this;

    var other;
    if ($this.otherGameObjectName && objects[$this.otherGameObjectName])
        other = objects[$this.otherGameObjectName].Physics.body;
    else
        other = window.groundBody;
    $this.distance = new p2.DistanceConstraint($this.gameObject.Physics.body, other, {
        localAnchorA: [$this.AnchorX, $this.AnchorY],
        localAnchorB: [$this.OtherAnchorX, $this.OtherAnchorY],
    });
    newObservable($this, "minDistance", undefined, function () {
        if ($this.minDistance == -1)
            $this.distance.lowerLimitEnabled = false;
        else {
            $this.distance.lowerLimitEnabled = true;
            $this.distance.lowerLimit = parseFloat($this.minDistance);
        }
    })();
    newObservable(this, "maxDistance", undefined, function () {
        if ($this.maxDistance == -1)
            $this.distance.upperLimitEnabled = false;
        else {
            $this.distance.upperLimitEnabled = true;
            $this.distance.upperLimit = parseFloat($this.maxDistance);
        }
    })();
    world.addConstraint($this.distance);

}
gm.distanceConstraint.prototype.dispose = function () {
    world.removeConstraint(this.distance);
}

function initiatePhysicsEngine() {
    window.world = new p2.World({
        gravity: [0, 982]
    });
    world.solver.iterations = 8;
    world.solver.tolerance = 0.01;
    initializeMaterials();
    world.on("impact", function (evt) {
        var bodyA = evt.bodyA,
            bodyB = evt.bodyB;
        for (var i = 0; i < impactFunctions.length; i++) {
            if (impactFunctions[i].gameObject && impactFunctions[i].gameObject && impactFunctions[i].gameObject.Physics
                && impactFunctions[i].gameObject.Physics.body) {
                if (impactFunctions[i].gameObject.Physics.body == bodyA)
                    impactFunctions[i].fn.apply(impactFunctions[i].component,[ getGameObject(bodyB), bodyB, evt]);
                else if (impactFunctions[i].gameObject.Physics.body == bodyB)
                    impactFunctions[i].fn.apply(impactFunctions[i].component, [getGameObject(bodyA), bodyA, evt]);
            }
        }
    });
    world.on("beginContact", function (evt) {
        var bodyA = evt.bodyA,
            bodyB = evt.bodyB;
        for (var i = 0; i < beginContactFunctions.length; i++) {
            if (beginContactFunctions[i].gameObject && beginContactFunctions[i].gameObject && beginContactFunctions[i].gameObject.Physics
                && beginContactFunctions[i].gameObject.Physics.body) {
                if (beginContactFunctions[i].gameObject.Physics.body == bodyA)
                    beginContactFunctions[i].fn.apply(beginContactFunctions[i].component, [getGameObject(bodyB), bodyB, evt]);
                else if (beginContactFunctions[i].gameObject.Physics.body == bodyB)
                    beginContactFunctions[i].fn.apply(beginContactFunctions[i].component, [getGameObject(bodyA), bodyA, evt]);
            }
        }
    });
    world.on("endContact", function (evt) {
        var bodyA = evt.bodyA,
            bodyB = evt.bodyB;
        for (var i = 0; i < endContactFunctions.length; i++) {
            if (endContactFunctions[i].gameObject && endContactFunctions[i].gameObject && endContactFunctions[i].gameObject.Physics
                && endContactFunctions[i].gameObject.Physics.body) {
                if (endContactFunctions[i].gameObject.Physics.body == bodyA)
                    endContactFunctions[i].fn.apply(endContactFunctions[i].component, [getGameObject(bodyB), bodyB, evt]);
                else if (endContactFunctions[i].gameObject.Physics.body == bodyB)
                    endContactFunctions[i].fn.apply(endContactFunctions[i].component, [getGameObject(bodyA), bodyA, evt]);
            }
        }
    });
}
function getGameObject(body) {
    return objects[body.gameObjectName];
}